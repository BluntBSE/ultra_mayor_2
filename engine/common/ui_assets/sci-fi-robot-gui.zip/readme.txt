Fonts that was used:
https://www.dafont.com/robotica-courtney.font