Thank you for buying my item!

In the Main folder you will find another 5 folders that contain the different types of file of the icons. The files can be found
in JPG, PNG and editable PSD
The PSD file can be edited as you like in Photoshop or other program, JPG and PNG are ready for use as they are.

If you have any questions, don't hesitate to contact me on my profile or use my e-mail: icosteaa13@gmail.com